package Merchant_e_Solutions.Merchant_Automation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

public class UserFiltersTc extends MerchantBase {

	UserFilters userFilters;
	
	@Test(priority = 0)
	public void loginAdmin() throws InterruptedException {
		userFilters = new UserFilters (driver);
		userFilters.clickUserMenu();
	}
	
	@Test(priority = 1)
	public void selectUserNameDropdownBox() throws IOException {
		userFilters = new UserFilters (driver);
		List<String> uName = new ArrayList<>();
		List<String> userNames = userFilters.clickUserNameDropdownBox();
		Map<String, String> userNameValues = ReadTestDataUtil.readExcel("./Testdata", "Merchant_TestCases.xlsx", "User_Filters_TestData", "M_U_002_Step_003");	
		userNameValues.forEach((k, v) -> {
		System.out.println("Key: " + k + ", Value: " + v);
		uName.add(k);
		});
		
		System.out.println("user check" + userNames.contains(uName));
		//Assert.assertEquals(true, userNames.contains(uName));
						
	}
	
	@Test(priority = 2)
	public void selectEmailDropdownBox() throws IOException {
		userFilters = new UserFilters (driver);
		List<String> email = new ArrayList<>();
		List<String> emailId = userFilters.clickEmailDropdownBox();
		Map<String, String> emailIdValues = ReadTestDataUtil.readExcel("./Testdata", "Merchant_TestCases.xlsx", "User_Filters_TestData", "M_U_002_Step_011");	
		emailIdValues.forEach((option, value) -> {
		// System.out.println("Key: " + k + ", Value: " + v);
		email.add(option);
		});
		System.out.println("emial check " + emailId.contains(email));
		//Assert.assertEquals(true, emailId.contains(email));

	}
	
	@Test(priority = 3)
	public void applyUserNameFilter() throws IOException{
		userFilters = new UserFilters (driver);
		Map<String, String> userNameValues = ReadTestDataUtil.readExcel("./Testdata", "Merchant_TestCases.xlsx", "User_Filters_TestData", "M_U_002_Step_003");	
		userNameValues.forEach((option, value) -> {
		userFilters.setUserName(option, value);
		userFilters.clickOnFilterButton();
		try {
			Thread.sleep(5000);
			screenshot("userNameFilter_" + option);
		} catch (InterruptedException | IOException e) {
	
		}
		});
	}
	
	@Test(priority = 4)
	public void applyEmailFilter() throws IOException{
		userFilters = new UserFilters (driver);
		Map<String, String> emailValues  = ReadTestDataUtil.readExcel("./Testdata", "Merchant_TestCases.xlsx", "User_Filters_TestData", "M_U_002_Step_011");	
		emailValues.forEach((option, value) -> {
		userFilters.setEmail(option, value);
		userFilters.clickOnFilterButton();
		try {
			Thread.sleep(5000);
			screenshot("emailFilter_" + option);
		} catch (InterruptedException | IOException e) {
	
		}
		});
	}
	
	@Test(priority = 5)
	public void applyDatesFilter() throws IOException{
		userFilters = new UserFilters (driver);
		Map<String, String> emailValues  = ReadTestDataUtil.readExcel("./Testdata", "Merchant_TestCases.xlsx", "User_Filters_TestData", "M_U_002_Step_018");	
		emailValues.forEach((option, value) -> {
		userFilters.setDates(option, value);
		userFilters.clickOnFilterButton();
		try {
			Thread.sleep(5000);
			screenshot("datesFilter");
		} catch (InterruptedException | IOException e) {
	
		}
		});
	}
	
}
