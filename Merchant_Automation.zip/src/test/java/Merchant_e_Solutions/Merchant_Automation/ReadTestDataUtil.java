package Merchant_e_Solutions.Merchant_Automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadTestDataUtil {

	public static Map<String, String> readExcel(String filePath,String fileName,String sheetName, String testCase) throws IOException{

	    //Create an object of File class to open xlsx file

	    File file =    new File(filePath+"\\"+fileName);

	    //Create an object of FileInputStream class to read excel file

	    FileInputStream inputStream = new FileInputStream(file);

	    Workbook merchantTestData = new XSSFWorkbook(inputStream);
	    

	    //Read sheet inside the workbook by its name

	    Sheet testDataSheet = merchantTestData.getSheet(sheetName);

	    //Find number of rows in excel file

	    int rowCount = testDataSheet.getLastRowNum()-testDataSheet.getFirstRowNum();

	    // To Create Hashmap to store values from excel
	    Map <String, String> testDataMap = new HashMap<>();
	    
	  //Create a loop over all the rows of excel file to read it
	    for (int i = 0; i < rowCount+1; i++) {

	        Row row = testDataSheet.getRow(i);
	     
//	        for (int j = 0; j < row.getLastCellNum(); j++) {	      
//
//	            System.out.print(row.getCell(j).getStringCellValue()+"|| ");          
//	            
//	        }
//
//	        System.out.println();
	        
	        //Write if Conditon to compare test cases value with Column value
	        if (testCase.equals(row.getCell(0).getStringCellValue())) {
	        	
		       String key =	row.getCell(1).getStringCellValue();
		       String value = row.getCell(2).getStringCellValue();
		       testDataMap.put(key, value);	      
		       System.out.println("key: " + key + " value: " + value);
	        }
	      
	    } 
	    
	    merchantTestData.close();
	    return testDataMap;
	    

	}
}
