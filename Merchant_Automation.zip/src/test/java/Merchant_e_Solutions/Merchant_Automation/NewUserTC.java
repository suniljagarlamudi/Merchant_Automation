package Merchant_e_Solutions.Merchant_Automation;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.Test;

public class NewUserTC extends MerchantBase {
	NewUser newUser;

	@Test(priority = 0)
	public void loginAdmin() throws InterruptedException {
		newUser = new NewUser(driver);
		newUser.clickUserMenu();
	}

	@Test(priority = 1)
	public void cancelNewUser() throws InterruptedException, FileNotFoundException, IOException {
		newUser = new NewUser(driver);
		newUser.clickNewUserButton();
		newUser.enterUserName("UserName");
		newUser.enterPassWord("PassWord");
		newUser.enterEmail("Email");
		newUser.clickOnCancel();
	}	

	@Test(priority = 2)
	public void createNewuser() throws InterruptedException, FileNotFoundException, IOException {
		newUser = new NewUser(driver);
		newUser.clickNewUserButton();
		newUser.enterUserName("UserName");
		newUser.enterPassWord("PassWord");
		newUser.enterEmail("Email");
		newUser.clickOnCreateUser();
	}

}
