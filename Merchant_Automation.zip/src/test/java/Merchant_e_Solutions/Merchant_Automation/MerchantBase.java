package Merchant_e_Solutions.Merchant_Automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class MerchantBase {
	public WebDriver driver;

	@BeforeTest
	public void setup() throws FileNotFoundException, IOException {
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(LoginGetProperty("URL"));
		driver.manage().window().maximize();
	}

	private static Properties Loginconfig;

	public  static String LoginGetProperty(String Name) throws FileNotFoundException, IOException {
		if (Loginconfig == null) {
			Loginconfig = new Properties();
			Loginconfig.load(new FileInputStream("./TestData/Loginconfigfile.properties"));
		}
		return Loginconfig.getProperty(Name);
	}
	
	public  void screenshot(String fileName) throws IOException {
		File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd_HHmmss");

		String destinationFileName = fileName +"_"+ simpleDateFormat.format(new Date());

		FileUtils.copyFile(source, new File("./ScreenShots/" + destinationFileName + ".png"));
	}


	@AfterTest
	public void closeUrl() throws InterruptedException {
		Thread.sleep(1000);
		driver.quit();
	}

}// End Bracket
