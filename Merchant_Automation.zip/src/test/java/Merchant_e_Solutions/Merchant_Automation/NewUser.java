package Merchant_e_Solutions.Merchant_Automation;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewUser {

	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"users\"]/a")
	public WebElement user;

	@FindBy(xpath = "//*[@id=\"titlebar_right\"]/div/span/a")
	public WebElement newuser;

	@FindBy(xpath = "//*[@id=\"user_username\"]")
	public WebElement Username;

	@FindBy(xpath = "//*[@id=\"user_password\"]")
	public WebElement Password;

	@FindBy(xpath = "//*[@id=\"user_email\"]")
	public WebElement Email;

	@FindBy(xpath = "//*[@id=\"user_submit_action\"]/input")
	public WebElement CreateuserButton;

	@FindBy(xpath = "//*[@id=\"new_user\"]/fieldset[2]/ol/li[2]/a")
	public WebElement CancelButton;

	public NewUser(WebDriver driver) {
		this.driver = driver;
		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}

	public void clickUserMenu() throws InterruptedException {
		user.click();
		Thread.sleep(5000);
	}

	public void clickNewUserButton() throws InterruptedException {
		newuser.click();
		Thread.sleep(5000);
	}

	public void enterUserName(String userNameKey) throws FileNotFoundException, IOException {
		// Username.sendKeys(UserName);
		String userNameValue = MerchantBase.LoginGetProperty(userNameKey);
		clearUsername();
		Username.sendKeys(userNameValue);

	}

	public void enterPassWord(String passWordKey) throws FileNotFoundException, IOException {
		// Password.sendKeys(PassWord);
		String passWordValue = MerchantBase.LoginGetProperty(passWordKey);
		clearPassword();
		Password.sendKeys(passWordValue);
	}

	public void enterEmail(String emailKey) throws FileNotFoundException, IOException {
		// Email.sendKeys(EmailID);
		String emailValue = MerchantBase.LoginGetProperty(emailKey);
		clearEmail();
		Email.sendKeys(emailValue);
	}

	public void clickOnCreateUser() throws InterruptedException {
		CreateuserButton.click();
		Thread.sleep(10000);
	}

	public void clickOnCancel() {
		CancelButton.click();
	}

	public void clearUsername() {
		Username.clear();
	}

	public void clearPassword() {
		Password.clear();
	}

	public void clearEmail() {
		Email.clear();
	}

}// EndBracket
