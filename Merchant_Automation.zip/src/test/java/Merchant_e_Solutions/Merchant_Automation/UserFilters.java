package Merchant_e_Solutions.Merchant_Automation;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class UserFilters {

	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"users\"]/a")
	WebElement user;

	@FindBy(xpath = "//*[@id=\"q_username_input\"]/select")
	WebElement userFilterUserNameDropdown;

	@FindBy(xpath = "//*[@id=\"q_username\"]")
	WebElement userFilterUserNameTextBox;

	@FindBy(xpath = "//*[@id=\"q_email_input\"]/select")
	WebElement userFilterEmailDropdown;

	@FindBy(xpath = "//*[@id=\"q_email\"]")
	WebElement userFilterEmailTextBox;

	@FindBy(xpath = "//*[@id=\"q_created_at_gteq_datetime\"]")
	WebElement userFilterFromDate;
	
	@FindBy (xpath = "//*[@id=\"ui-datepicker-div\"]/div/a[1]")
	WebElement fromDatePreviousArrow;
	
	@FindBy (xpath = "//*[@id=\"ui-datepicker-div\"]/div/a[2]")
	WebElement fromDateNextArrow;
	
	@FindBy (xpath = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[3]/a")
	WebElement fromDateSelect;
	
	@FindBy(xpath = "//*[@id=\"q_created_at_lteq_datetime\"]")
	WebElement userFilterToDate;
	
	@FindBy (xpath = "//*[@id=\"ui-datepicker-div\"]/div/a[1]")
	WebElement toDatePreviousArrow;
	
	@FindBy (xpath = "//*[@id=\"ui-datepicker-div\"]/div/a[2]")
	WebElement toDateNextArrow;
	
	@FindBy (xpath = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[6]/a")
	WebElement toDateSelect;
	
	@FindBy (xpath = "//*[@id=\"new_q\"]/div[4]/input[1]")
	WebElement filterButton;

	public UserFilters(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickUserMenu() throws InterruptedException {
		user.click();
		Thread.sleep(5000);
	}

	public List<String>  clickUserNameDropdownBox() {
		Select select = new Select(userFilterUserNameDropdown);
		List<WebElement> userNameOptions = select.getOptions();
		List<String> userNameValues = new ArrayList<>();
		for (WebElement userNameOption : userNameOptions) {

			System.out.println("Dropdown values are " + userNameOption.getText());
			
			userNameValues.add(userNameOption.getText());
		}
		return userNameValues;
		
	}

	public List<String>  clickEmailDropdownBox() {
		Select select = new Select(userFilterEmailDropdown);
		List<WebElement> emailOptions = select.getOptions();
		List<String> emailValues = new ArrayList<>();
		for (WebElement emailOption : emailOptions) {

			System.out.println("Dropdown values are " + emailOption.getText());
			
			emailValues.add(emailOption.getText());
		}
		return emailValues;
		
	}
	
	public void setUserName(String option, String value) {
		Select select = new Select(userFilterUserNameDropdown);
		select.selectByVisibleText(option);
		userFilterUserNameTextBox.clear();
		userFilterUserNameTextBox.sendKeys(value);
	}
	
	public void clickOnFilterButton() {
		filterButton.click();
	}
	
	
	public void setEmail(String option, String value) {
		Select select = new Select(userFilterEmailDropdown);
		select.selectByVisibleText(option);
		userFilterUserNameTextBox.clear();
		userFilterEmailTextBox.clear();
		userFilterEmailTextBox.sendKeys(value);
	}
	
	public void setDates(String fromDate, String toDate) {
		userFilterUserNameTextBox.clear();
		userFilterEmailTextBox.clear();
		userFilterFromDate.clear();
		userFilterFromDate.sendKeys(fromDate);
		userFilterToDate.clear();
		userFilterToDate.sendKeys(toDate);
		
	}
	
	
	
}
